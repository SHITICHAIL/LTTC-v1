defmodule BlockScoutWeb.LogView do
  use BlockScoutWeb, :view
end
