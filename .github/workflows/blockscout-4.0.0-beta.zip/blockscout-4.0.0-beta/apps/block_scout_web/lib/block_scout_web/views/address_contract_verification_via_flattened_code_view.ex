defmodule BlockScoutWeb.AddressContractVerificationViaFlattenedCodeView do
  use BlockScoutWeb, :view

  alias Explorer.Chain
end
