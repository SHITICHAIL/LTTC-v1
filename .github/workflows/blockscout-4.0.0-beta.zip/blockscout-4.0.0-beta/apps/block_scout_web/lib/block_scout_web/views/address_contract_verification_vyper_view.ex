defmodule BlockScoutWeb.AddressContractVerificationVyperView do
  use BlockScoutWeb, :view

  alias Explorer.Chain
end
