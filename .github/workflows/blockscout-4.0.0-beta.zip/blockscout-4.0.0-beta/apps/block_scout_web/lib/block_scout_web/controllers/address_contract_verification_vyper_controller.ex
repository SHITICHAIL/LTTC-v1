defmodule BlockScoutWeb.AddressContractVerificationVyperController do
  use BlockScoutWeb, :controller

  alias Explorer.Chain.SmartContract
  alias Explorer.SmartContract.{CompilerVersion, Vyper.PublisherWorker}

  def new(conn, %{"address_id" => address_hash_string}) do
    changeset =
      SmartContract.changeset(
        %SmartContract{address_hash: address_hash_string},
        %{}
      )

    compiler_versions =
      case CompilerVersion.fetch_versions(:vyper) do
        {:ok, compiler_versions} ->
          compiler_versions

        {:error, _} ->
          []
      end

    render(conn, "new.html",
      changeset: changeset,
      compiler_versions: compiler_versions,
      address_hash: address_hash_string
    )
  end

  def create(
        conn,
        %{
          "smart_contract" => smart_contract
        }
      ) do
    Que.add(PublisherWorker, {smart_contract["address_hash"], smart_contract, conn})

    send_resp(conn, 204, "")
  end

  def parse_optimization_runs(%{"runs" => runs}) do
    case Integer.parse(runs) do
      {integer, ""} -> integer
      _ -> 200
    end
  end
end
