defmodule BlockScoutWeb.CaptchaView do
  use BlockScoutWeb, :view
end
