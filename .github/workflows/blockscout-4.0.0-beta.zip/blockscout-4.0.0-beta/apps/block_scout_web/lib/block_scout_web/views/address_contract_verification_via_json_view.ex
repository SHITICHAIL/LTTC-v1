defmodule BlockScoutWeb.AddressContractVerificationViaJsonView do
  use BlockScoutWeb, :view
end
