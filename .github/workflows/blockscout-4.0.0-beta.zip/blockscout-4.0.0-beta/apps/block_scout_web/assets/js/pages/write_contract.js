import '../lib/smart_contract/write'
