function isFiltered (filter) {
  return (filter === 'to' || filter === 'from')
}

export { isFiltered }
