// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'unsubscribed_message.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

UnsubscribedMessage _$UnsubscribedMessageFromJson(Map<String, dynamic> json) =>
    UnsubscribedMessage(
      result: json['result'] as int,
      id: json['id'] as int,
    );
