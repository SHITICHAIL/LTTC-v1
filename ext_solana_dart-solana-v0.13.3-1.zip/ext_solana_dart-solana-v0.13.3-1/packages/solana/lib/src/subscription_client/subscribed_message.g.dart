// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'subscribed_message.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SubscribedMessage _$SubscribedMessageFromJson(Map<String, dynamic> json) =>
    SubscribedMessage(
      result: json['result'] as int,
      id: json['id'] as int,
    );
