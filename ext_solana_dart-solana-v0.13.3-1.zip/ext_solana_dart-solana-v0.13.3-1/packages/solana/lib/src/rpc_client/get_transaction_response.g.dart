// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_transaction_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GetTransactionResponse _$GetTransactionResponseFromJson(
        Map<String, dynamic> json) =>
    GetTransactionResponse(
      TransactionResponse.fromJson(json['result'] as Map<String, dynamic>),
    );
