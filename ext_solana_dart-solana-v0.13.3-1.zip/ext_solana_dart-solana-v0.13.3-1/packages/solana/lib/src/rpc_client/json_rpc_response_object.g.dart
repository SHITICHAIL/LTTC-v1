// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'json_rpc_response_object.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ValueResponse<T> _$ValueResponseFromJson<T>(
  Map<String, dynamic> json,
  T Function(Object? json) fromJsonT,
) =>
    ValueResponse<T>(
      value: fromJsonT(json['value']),
    );
