// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'blockhash_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

BlockhashResponse _$BlockhashResponseFromJson(Map<String, dynamic> json) =>
    BlockhashResponse(
      ValueResponse.fromJson(json['result'] as Map<String, dynamic>,
          (value) => Blockhash.fromJson(value as Map<String, dynamic>)),
    );
