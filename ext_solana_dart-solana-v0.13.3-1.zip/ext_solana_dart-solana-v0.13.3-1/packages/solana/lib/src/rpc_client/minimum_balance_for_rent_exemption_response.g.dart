// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'minimum_balance_for_rent_exemption_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

MinimumBalanceForRentExemptionResponse
    _$MinimumBalanceForRentExemptionResponseFromJson(
            Map<String, dynamic> json) =>
        MinimumBalanceForRentExemptionResponse(
          json['result'] as int,
        );
