typedef ByteArray = Iterable<int>;
