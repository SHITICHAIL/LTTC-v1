// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'json_rpc_exception.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

JsonRpcException _$JsonRpcExceptionFromJson(Map<String, dynamic> json) =>
    JsonRpcException(
      json['message'] as String,
      json['code'] as int,
      json['data'],
    );
