// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'parsed_message_header.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ParsedMessageHeader _$ParsedMessageHeaderFromJson(Map<String, dynamic> json) =>
    ParsedMessageHeader(
      numRequiredSignatures: json['numRequiredSignatures'] as int,
      numReadonlySignedAccounts: json['numReadonlySignedAccounts'] as int,
      numReadonlyUnsignedAccounts: json['numReadonlyUnsignedAccounts'] as int,
    );
