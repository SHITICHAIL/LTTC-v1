## 0.2.0+1

 - **FIX**: Remove build.yaml from borsh_annotation (#61).
 - **CHORE**: Splits borsh package (#60).

## 0.2.0

 - Initial version

